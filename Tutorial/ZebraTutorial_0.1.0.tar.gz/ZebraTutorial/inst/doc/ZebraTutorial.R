## ---- include = FALSE----------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup, include=FALSE------------------------------------------------
knitr::opts_chunk$set(echo = TRUE)
options(tibble.width = Inf)

library(ZebraTutorial)

## ---- echo=T, eval=F-----------------------------------------------------
#  install.packages(path_to_file, repos = NULL, type="source") #path_to_file is a character string that points to
#    #the downloaded file, e.g., install.packages("ZebraTutorial_0.1.0.tar.gz", repos = NULL, type="source")
#    #if the file is in your working directory

## ---- echo=T, eval=F-----------------------------------------------------
#  library(devtools) #this takes awhile to install so install from source if you don't want to bother
#  install_github("troutinthemilk/Zeebs-Season2/Tutorial/ZebraTutorial", build_vignettes = TRUE)

## ---- echo=TRUE, warning=F, message=F------------------------------------
library(ZebraTutorial)
library(tidyverse) #we will use some functions from this set of packages

## ------------------------------------------------------------------------
data(DoubleEncounter)
head(DoubleEncounter)

## ------------------------------------------------------------------------
data(DoubleTransect)
DoubleTransect    <- DoubleTransect %>% gather(key = observer, value = name, "primary", "secondary") 
head(DoubleTransect)

## ---- warning=F----------------------------------------------------------
library(FSA) #load the FSA library

#returns data in a form that can be used by removal in FSA
removal.list <- create.removal(DoubleEncounter, DoubleTransect) 

## ---- warning=F, messages=F----------------------------------------------

#get the length of each transect
length.vec  <- DoubleTransect %>% group_by(`Transect number`) %>% summarize(length = first(length)) 

# now sum the results over all transects to estimate
# population size at the transect level 
remove.ests <- removal(removal.list, just.ests=TRUE)
Nhat       <- remove.ests[1]
Nhat.SE    <- remove.ests[2]

# estimate of density along the transect

# estimate of detection probability along the transect
bp.hat      <- remove.ests[5]
bpSE.phat   <- remove.ests[6]

#we need to incorporate variation of detection and variation in the conditional counts into the the density estimate
Dhat      <- Nhat/sum(length.vec$length)
Dhat.SE   <- Dhat*sqrt((Nhat.SE^2/sum(removal.list)^2) + bpSE.phat/bp.hat^2)


## ----removalNotPooled, echo=F, eval=F------------------------------------
#  removal.list <- create.removal(DoubleEncounter, DoubleTransect, pool.transects = F)
#  
#  #get the length of each transect
#  length.vec  <- DoubleTransect %>% group_by(`Transect number`) %>% summarize(length = first(length))
#  
#  # now sum the results over all transects to estimate
#  # population size at the transect level
#  remove.ests <- lapply(removal.list, removal, just.ests=TRUE)
#  
#  bN.hat <- sum(data.frame(remove.ests)[1,])
#  bD.hat <- bN.hat/sum(length.vec)
#  
#  bSE.Nhat <- sqrt(sum(data.frame(remove.ests)[2,]^2, na.rm = TRUE))
#  bSE.Dhat <- bSE.Nhat/sum(length.vec)#0.01341253
#  
#  bp.hat <- mean(unlist(data.frame(remove.ests)[5,]), na.rm = TRUE)
#  bSE.phat <- sqrt(mean(unlist(data.frame(remove.ests)[6,])^2, na.rm = TRUE))
#  
#  Dhat.SE <- sqrt(bSE.Dhat^2 + bD.hat^2*bSE.phat/bp.hat^2) #0.05138855

## ----removalDesign, echo=F, eval=F---------------------------------------
#  
#  removal.list <- create.removal(DoubleEncounter, DoubleTransect, pool.transects=F)
#  length.vec  <- DoubleTransect %>% group_by(`Transect number`) %>% summarize(length = first(length))
#  length.vec <- length.vec$length
#  
#  # now sum the results over all transects to estimate
#  # population size at the transect level
#  #remove.ests <- lapply(removal.list, removal, just.ests=TRUE)
#  
#  #area    <- DistanceTransect$`Transect length (if transect survey)` #length of transects
#  counts  <- unlist(lapply(removal.list, sum))
#  n       <- length(length.vec) #total number of transects
#  w       <- 1 #width of transects
#  Phat    <- 0.8082192  #from distance model
#  VarP    <- 0.06808811^2 #from calculation above
#  
#  #get density esimate and its standard error.
#  Dhat    <- sum(counts)/(sum(area)*Phat)
#  VarX    <- sum(area)*sum(area*(counts/area - sum(counts)/sum(area))^2)/(n-1)
#  
#  VarD <- Dhat^2*(VarX/sum(counts)^2 + VarP/Phat^2)
#  
#  Dhat.SE <- sqrt(VarD) #0.07925382

## ------------------------------------------------------------------------
data("DistanceEncounter")
head(DistanceEncounter)

## ------------------------------------------------------------------------
data("DistanceTransect")
head(DistanceTransect)

# order by transect number
DistanceTransect    <- DistanceTransect[order(DistanceTransect$"Transect number"),]

## ----pressure, fig.cap="Figure 1. Diagnositic plot of the detection distance, the distance of each detection from the transect line.", fig.asp=0.7----
hist(DistanceEncounter$distance, col="black", border="white",
     xlab='Distance of detection from transect (cm)', main="")

## ---- warning=F----------------------------------------------------------
library(mrds) #load the mrds package

# Order the transects
DistanceEncounter     <- DistanceEncounter[order(DistanceEncounter$`Transect #`),]

# Format distance data for use with mrds
DistanceEncounter     <- DistanceEncounter %>% 
        mutate(detected = rep(1, dim(DistanceEncounter)[1]),
                                object=1:dim(DistanceEncounter)[1]) 
distance.rem.dat      <- create.removal.Observer(transect.dat=DistanceTransect, obs.dat=DistanceEncounter) 


## ---- warning=F----------------------------------------------------------
distance.model  <- ddf(method="rem", dsmodel=~cds(key="hr"),
                       mrmodel=~glm(formula=~1),
                       data=distance.rem.dat,
                       meta.data=list(width=100))

print(summary(distance.model))

## ---- warning=F----------------------------------------------------------
plot(distance.model, which=2, showpoints=FALSE, lwd=2)

## ------------------------------------------------------------------------
area    <- DistanceTransect$`Transect length (if transect survey)` #length of transects
counts  <- table(DistanceEncounter$`Transect #`) #count in each transect
n       <- length(area) #total number of transects
w       <- 2 #width of transects
Phat    <- 0.58 #from distance model
VarP    <- 0.06^2 #from calculation above

#get density esimate and its standard error.
Dhat    <- sum(counts)/(w*sum(area)*Phat)
VarX    <- sum(area)*sum(area*(counts/area - sum(counts)/sum(area))^2)/(n-1)
  
VarD <- Dhat^2*(VarX/sum(counts)^2 + VarP/Phat^2)

