#' Encounters of zebra mussels in Lake Burgen, MN
#'
#' Number of zebra mussel encounters made by two observers in a double-observer removal design.
#'
#' @docType data
#'
#' @usage data(DoubleEncounter)
#'
#' @format
#'
#' \describe{
#'     \item{Observer name}{The name of the observer that made the detection}
#'     \item{Transect number}{The transect the detection was made on}
#'     \item{size}{The number of individual mussels in the detection event.}
#' }
#' @keywords datasets
#'
#' @source \href{https://github.com/troutinthemilk/Zeebs-Season2/blob/master/Tutorial/EncountersDoubleTutorial.xlsx}{github}, based on data from \href{https://conservancy.umn.edu/handle/11299/201572}{Data Repository for University of Minnesota}
#'
#' @examples
#' data(DoubleEncounter)
"DoubleEncounter"
