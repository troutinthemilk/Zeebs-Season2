#' Transect information for zebra mussels in Lake Burgen, MN
#'
#' Transects surveyed by two observers in a double-observer removal design.
#'
#' @docType data
#'
#' @usage data(DoubleTransect)
#'
#' @format
#'
#' \describe{
#'     \item{primary}{The name of the primary observer on this transect}
#'     \item{secondary}{The name of the secondary observer on this transect}
#'     \item{length}{The length of the current transect}
#'     \item{Transect number}{The current transect}
#' }
#' @keywords datasets
#'
#' @source \href{https://github.com/troutinthemilk/Zeebs-Season2/blob/master/Tutorial/EncountersDoubleTransect.xlsx}{github}, based on data from \href{https://conservancy.umn.edu/handle/11299/201572}{Data Repository for University of Minnesota}
#'
#' @examples
#' data(DoubleTransect)
"DoubleTransect"
